<div id="footer">
<div class="wrap">
<div class="wrapper">
<span>
<a href="" class="brand"></a>
<div>@2011 安卓壁纸 京ICP备13008053</div>
</span>
<span>
<h1>关于我们</h1>
<a href="http://pic.adesk.com/howto">了解光点</a>
</span>
<span>
<h1>联系我们</h1>
<p>电话 : 0000000000</p>
<p>邮箱 : BD@adesk.com(来件必复)</p>
<p>用户QQ群1 : 0000000000</p>
<p>用户QQ群2 : 0000000000</p>
<p>用户QQ群3 : 0000000000</p>
</span>
<span class="focus">
<h1>关注我们</h1>
<a href="http://e.weibo.com/1977161541" data-bypass="" target="_blank" class="sina"><span class="p"></span>新浪微博</a>
<a href="http://t.qq.com/androidesk" data-bypass="" target="_blank" class="tencent"><span class="p"></span>腾讯微博</a>
<a href="javascript:void(0);" class="weixin">
<span class="p"></span>微信
<img src="<?php bloginfo('template_url'); ?>/images/weixin_code.jpg">
</a>
</span>
<span class="link">
<h1>友情链接</h1>
<p>
<span><a href="http://www.androidesk.com/" data-bypass="" target="_blank">安卓壁纸</a></span>
</p>
</span>
</div>
</div>
</div>

<script>
var app = {login: false};
app['user'] = {};
</script>

<script>
app.cates = {
'stuff': '4fb47a465ba1c65561000028',
'creative': '4fb47a195ba1c60ca5000222',
'vision': '4fb479f75ba1c65561000027',
'cityscapes': '4fb47a305ba1c60ca5000223',
'animations': '4e4d610cdf714d2966000003',
'text': '5109e04e48d5b9364ae9ac45',
'celebrity': '5109e05248d5b9368bb559dc',
'landscape': '4e4d610cdf714d2966000002',
'emotion': '4ef0a35c0569795756000000',
'girl': '4e4d610cdf714d2966000000',
'movies': '4e58c2570569791a19000000',
'sports': '4ef0a34e0569795757000001',
'art': '4ef0a3330569795757000000',
'men': '4e4d610cdf714d2966000006',
'animals': '4e4d610cdf714d2966000001',
'games': '4e4d610cdf714d2966000007',
'enginery': '4e4d610cdf714d2966000005',
'others': '4e4d610cdf714d2966000004'
};
app.cates_en = {
'stuff': '物语',
'creative': '创意',
'vision': '视觉',
'cityscapes': '城市',
'animations': '动漫',
'landscape': '风景',
'emotion': '情感',
'girl': '美女',
'movies': '影视',
'sports': '运动',
'art': '艺术',
'men': '男人',
'animals': '动物',
'games': '游戏',
'enginery': '机械',
'others': '其他',
'text': '文字',
'celebrity':'明星'
};
</script>
<!--
<script data-main="/static/app/config" src="/static/assets/js/libs/require.js"></script>
-->

<!-- <script src="http://s.androidesk.com/androidesk/js/main.js?v=20130403_1"></script>-->
<script src="http://zhushou.360.cn/script/360mobilemgrdownload.js"></script>
<script type="text/javascript">
var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-38694198-1']);
_gaq.push(['_setDomainName', 'adesk.com']);
_gaq.push(['_trackPageview']);
(function() {
var ga = document.createElement('script'); ga.type = 'text/javascript';
ga.async = true;
ga.src = ('https:' == document.location.protocol ? 'https://ssl' :
'http://www') + '.google-analytics.com/ga.js';
var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(ga, s);
})();
</script>
</body>
</html>
